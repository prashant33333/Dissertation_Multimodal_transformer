import torch
import torch.nn as nn
import torch.nn.functional as F
import os

# -------------------------------------------------
# Device configuration
# -------------------------------------------------
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

class CrossAttention(nn.Module):
    #Attention is split into 8 parallel heads
    def __init__(self, dim=768, num_heads=8, dropout=0.3):#Each head learns different alignment patterns.
        super().__init__()
        self.attn = nn.MultiheadAttention(
            embed_dim=dim,
            num_heads=num_heads,
            dropout=dropout,
            batch_first=True #[Batch, Sequence, Features]
        )
        self.norm = nn.LayerNorm(dim) #Normalizes across features, Prevents one modality from dominating

    def forward(self, query, key_value):
        """
        This function lets one token (query) attend to a sequence of tokens (key/value) and returns a context-aware enriched query.

        query: [B, 1, D]
        B → batch size
        1 → exactly one token
        D → embedding dimension (e.g., 768)

        key_value: [B, N, D]
        N → number of tokens in another modality
        Audio frames
        Video patches
        Text tokens

        """
        #cross-attention computation
        attn_out, _ = self.attn(query, key_value, key_value) #attn_out=αV , _ contains attention maps
       # Residual connection , LayerNorm —> stabilizing the fusion
        return self.norm(attn_out + query)


class MultimodalEmotionModel(nn.Module):
    def __init__(self, embed_dim=768, num_heads=8, num_classes=8, dropout=0.3):
        super().__init__()
        #Learned NULL embeddings
        """ These are learnable placeholders.
            If one modality is missing, the model uses a learned null vector instead of undefined prediction/behaviour.

            Importance:
            1.Handles missing audio / text / video
            2.NULL vectors are trained, not fixed zeros
            3.Model learns how “absence” should influence emotion

            Shape: [768]
        """
        self.null_text   = nn.Parameter(torch.zeros(embed_dim))
        self.null_vision = nn.Parameter(torch.zeros(embed_dim))
        self.null_audio  = nn.Parameter(torch.zeros(embed_dim))


        #Cross-attention layers
        #This creates bidirectional multimodal understanding.
        self.audio_to_tv = CrossAttention(embed_dim, num_heads)  #Audio attends to Text + Vision
        self.text_to_av  = CrossAttention(embed_dim, num_heads)  #Text attends to Audio + Vision
        self.vision_to_at = CrossAttention(embed_dim, num_heads) #Vision attends to Audio + Text

        # Classifier
        self.classifier = nn.Sequential(
            nn.Linear(embed_dim * 3, 512),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(512, num_classes)
        )

    def forward(self, audio, text, vision, masks):

        # -------- MASKS --------
        text_mask   = masks[:, 0].unsqueeze(1)   # [B,1]
        vision_mask = masks[:, 1].unsqueeze(1)   # [B,1]
        audio_mask = masks[:, 2].unsqueeze(1)   # [B,1]

        # Replace missing modalities with learned NULL embeddings
        text = text_mask * text + (1 - text_mask) * self.null_text.unsqueeze(0)
        vision = vision_mask * vision + (1 - vision_mask) * self.null_vision.unsqueeze(0)
        audio = audio_mask * audio + (1 - audio_mask) * self.null_audio.unsqueeze(0)

        # -------- Attention Preparation --------
         #unsqueeze(1) turns a vector into a one-step sequence so attention can read it. ( attention only works on sequences)
        # [B,D](Batch, Features)->[B,T,D]([Batch, Sequence, Features])
        a = audio.unsqueeze(1)   # [B,1,D]
        t = text.unsqueeze(1)
        v = vision.unsqueeze(1)

        # Context pairs
        """
            Concatenation creates a context window of other modalities.
            a : [B, 1, 768]  → audio
            t : [B, 1, 768]  → text
            v : [B, 1, 768]  → vision

            Audio  → looks at [Text, Vision]
            Text   → looks at [Audio, Vision]
            Vision → looks at [Audio, Text]
        """

        tv = torch.cat([t, v], dim=1) #When AUDIO is thinking, let it look at both TEXT and VISION together.
        av = torch.cat([a, v], dim=1) #When TEXT is thinking, let it look at AUDIO and VISION together.
        at = torch.cat([a, t], dim=1) #When VISION is thinking, let it look at AUDIO and TEXT together.

        # Cross-attention fusion
        """
        Audio listens to text and vision, learns what matters, and becomes smarter

        a is the query (audio)
        tv is key/value (text + vision)
        Cross-attention happens inside

        a_fused = audio embedding enriched by text + vision

        """
        a_fused = self.audio_to_tv(a, tv).squeeze(1)
        t_fused = self.text_to_av(t, av).squeeze(1)
        v_fused = self.vision_to_at(v, at).squeeze(1)

        # Final fused representation
        fused = torch.cat([a_fused, t_fused, v_fused], dim=1)

        return self.classifier(fused)
    
"""#Load Audio extraction module"""

import os
import torch
import numpy as np
import soundfile as sf

from moviepy.editor import VideoFileClip
from transformers import Wav2Vec2Processor, Wav2Vec2Model

# -------------------------------------------------
# Load pretrained Wav2Vec2 model
# -------------------------------------------------
AUDIO_MODEL_NAME = "facebook/wav2vec2-base"
processor_audio = Wav2Vec2Processor.from_pretrained(AUDIO_MODEL_NAME)
model_audio = Wav2Vec2Model.from_pretrained(AUDIO_MODEL_NAME).to(DEVICE)
model_audio.eval()

# -------------------------------------------------
# Extract audio from MP4 using MoviePy
# -------------------------------------------------
def extract_audio_mp4_to_wav(mp4_path, wav_path):
    """
    Extracts audio from an MP4 file and saves it as a 16kHz mono WAV file.

    """
    video = VideoFileClip(mp4_path)

    if video.audio is None:
        video.close()
        raise ValueError(f"No audio stream found in {mp4_path}")

    video.audio.write_audiofile(
        wav_path,
        fps=16000,
        nbytes=2,
        codec="pcm_s16le",
        logger=None
    )

    video.close()

    # -------------------------------------------------
# Audio embedding extraction + saving
# -------------------------------------------------
@torch.no_grad()
def extract_audio_embedding(
    video_path,
    temp_wav_dir="_temp_wav"
):
    os.makedirs(temp_wav_dir, exist_ok=True)

    video_name = os.path.splitext(os.path.basename(video_path))[0]
    temp_wav_path = os.path.join(temp_wav_dir, f"{video_name}.wav")

    # 1. Extract WAV from MP4
    extract_audio_mp4_to_wav(video_path, temp_wav_path)

    # 2. Load WAV using soundfile
    waveform, sr = sf.read(temp_wav_path, dtype="float32")

    # Convert to mono if stereo
    if waveform.ndim == 2:
        waveform = waveform.mean(axis=1)

    waveform = torch.from_numpy(waveform)

    # 3. Prepare input for Wav2Vec2
    inputs = processor_audio(
        waveform,
        sampling_rate=sr,
        return_tensors="pt"
    ).to(DEVICE)

    # 4. Forward pass through Wav2Vec2
    outputs = model_audio(**inputs)

    # Frame-level embeddings: [time_steps, hidden_dim]
    hidden_states = outputs.last_hidden_state.squeeze(0)

    # -------------------------------------------------
    # ONE audio embedding per video (temporal mean)
    # -------------------------------------------------
    audio_embedding = hidden_states.mean(dim=0)  # [768]

    # L2 normalization
    audio_embedding = audio_embedding / audio_embedding.norm()

    # Cleanup temp WAV
    if os.path.exists(temp_wav_path):
        os.remove(temp_wav_path)

    return audio_embedding.cpu()

import os
import cv2
import torch
import numpy as np
from transformers import CLIPModel, CLIPProcessor

# -------------------------------------------------
# Load CLIP Vision model
# -------------------------------------------------
CLIP_NAME = "openai/clip-vit-base-patch32"
processor = CLIPProcessor.from_pretrained(CLIP_NAME)
model_visual = CLIPModel.from_pretrained(CLIP_NAME).to(DEVICE)
model_visual.eval()

# -------------------------------------------------
# Frame sampling using OpenCV
# -------------------------------------------------

def sample_frames_cv2(video_path, num_frames=8):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise ValueError(f"Cannot open video: {video_path}")

    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    if frame_count == 0:
        cap.release()
        raise ValueError(f"No frames found in video: {video_path}")

    indices = np.linspace(0, frame_count - 1, num_frames, dtype=int)
    frames = []

    for idx in indices:
        cap.set(cv2.CAP_PROP_POS_FRAMES, int(idx))
        ok, frame_bgr = cap.read()

        if not ok:
            frame_rgb = np.zeros((224, 224, 3), dtype=np.uint8)
        else:
            frame_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
            frame_rgb = cv2.resize(frame_rgb, (224, 224), interpolation=cv2.INTER_AREA)

        frames.append(frame_rgb)

    cap.release()
    return frames

   # -------------------------------------------------
# CLIP visual feature extraction + saving
# -------------------------------------------------

@torch.no_grad()
def extract_visual_embedding(
    video_path,
    num_frames=8
):
    # Sample frames
    frames = sample_frames_cv2(video_path, num_frames)

    # Preprocess frames
    inputs = processor(images=frames, return_tensors="pt").to(DEVICE)

    # Forward pass through CLIP vision encoder
    vision_outputs = model_visual.vision_model(**inputs)

    # CLS token embeddings (frame-level)
    z_v = vision_outputs.last_hidden_state[:, 0, :]  # [num_frames, 768]

    # ---------------------------------------------
    # Video-level embedding (ONE vector per video)
    # ---------------------------------------------
    video_embedding = z_v.mean(dim=0)  # [768]

    #l2 normalization

    video_embedding = video_embedding / video_embedding.norm()

    return video_embedding.cpu()

"""#initialize text feature extraction module"""

import os
import torch
import numpy as np
import soundfile as sf
from moviepy.editor import VideoFileClip
import whisper
from transformers import AutoTokenizer, AutoModel

# -------------------------------------------------
# Load offline Whisper (Speech → Text)
# -------------------------------------------------
whisper_model = whisper.load_model("base.pt")

# -------------------------------------------------
# Load Text Embedding Model
# -------------------------------------------------
TEXT_MODEL_NAME = "distilbert-base-uncased"
tokenizer = AutoTokenizer.from_pretrained(TEXT_MODEL_NAME)
text_model = AutoModel.from_pretrained(TEXT_MODEL_NAME).to(DEVICE)
text_model.eval()

# -------------------------------------------------
# Extract audio from MP4 using MoviePy
# -------------------------------------------------
def extract_audio_mp4_to_wav(mp4_path, wav_path):
    video = VideoFileClip(mp4_path)

    if video.audio is None:
        video.close()
        raise ValueError(f"No audio stream found in {mp4_path}")

    video.audio.write_audiofile(
        wav_path,
        fps=16000,
        nbytes=2,
        codec="pcm_s16le",
        logger=None
    )

    video.close()

    # -------------------------------------------------
# Text embedding extraction
# -------------------------------------------------
@torch.no_grad()
def extract_text_embedding(
    video_path,
    temp_wav_dir="_temp_wav"
):
    """
    Extracts:
        MP4 → WAV → Whisper Transcript → Transformer Text Embedding
    """

    os.makedirs(temp_wav_dir, exist_ok=True)

    # -------------------------------------------------
    # 1. Extract audio (.wav) from MP4
    # -------------------------------------------------
    video_name = os.path.splitext(os.path.basename(video_path))[0]
    temp_wav_path = os.path.join(temp_wav_dir, f"{video_name}.wav")

    extract_audio_mp4_to_wav(video_path, temp_wav_path)

    # -------------------------------------------------
    # 2. Load audio correctly (float32 + mono)
    # -------------------------------------------------
    audio, sr = sf.read(temp_wav_path, dtype="float32")

    # Stereo → Mono
    if audio.ndim == 2:
        audio = audio.mean(axis=1)

    # Normalize waveform
    max_amp = np.max(np.abs(audio))
    if max_amp > 0:
        audio = audio / max_amp

    # Resample to 16kHz (Whisper requirement)
    if sr != 16000:
        audio = whisper.audio.resample(audio, sr, 16000)

    # -------------------------------------------------
    # 3. Speech → Text (Deterministic Whisper)
    # -------------------------------------------------
    result = whisper_model.transcribe(
        audio,
        fp16=False,          # CPU safe
        language="en",       # fixed language
        temperature=0.0      # deterministic decoding
    )

    transcript = result["text"].strip()

    if not transcript:
        print(f"⚠️ Warning: No transcript generated for {video_path}")
        return

    # -------------------------------------------------
    # 4. Text → Embedding (Transformer CLS)
    # -------------------------------------------------
    inputs = tokenizer(
        transcript,
        return_tensors="pt",
        truncation=True,
        max_length=512
    ).to(DEVICE)

    outputs = text_model(**inputs)

    # CLS embedding
    text_embedding = outputs.last_hidden_state[:, 0, :].squeeze(0)

    # L2 normalize embedding
    text_embedding = text_embedding / text_embedding.norm(p=2)

    # -------------------------------------------------
    # 5. Cleanup
    # -------------------------------------------------
    if os.path.exists(temp_wav_path):
        os.remove(temp_wav_path)

    return text_embedding.cpu()

"""#Inference app"""

import gradio as gr

MODEL_LOAD_PATH = "multimodal_emotion_model.pth"


EMOTION_LABELS = ["Neutral",
                  "Calm",
                  "Happy",
                  "Sad",
                  "Angry",
                  "Fearful",
                  "Disgust",
                  "Surprised"
                  ]

# ===============================
# Load Emotion Model
# ===============================

print("Loading Multimodal Model...")
model_em = MultimodalEmotionModel()
model_em.load_state_dict(torch.load("multimodal_emotion_model.pth", map_location=DEVICE))
model_em.to(DEVICE)
model_em.eval()

# ===============================
#  Main Prediction Function
# ===============================

def predict_emotion(video_file):

    if video_file is None:
        return "❌ No video uploaded!"

    video_path = video_file

    print("🎥 Video received:", video_path)

    # -------------------------------
    # 1. Extract Visual Features
    # -------------------------------
    visual_feat = extract_visual_embedding(video_path)
    if visual_feat is None:
        print("ℹ️ No visuals detected → using NULL visual embedding")
        visual_feat = torch.zeros(768)
        visual_mask = 0
    else:
        visual_mask = 1

    visual_feat = visual_feat.to(DEVICE)

    # -------------------------------
    # 2. Extract Audio Features
    # -------------------------------
    audio_feat = extract_audio_embedding(video_path)

    if audio_feat is None:
        print("ℹ️ No Audio detected → using NULL audio embedding")
        audio_feat = torch.zeros(768)
        audio_mask = 0
    else:
      audio_mask = 1

    audio_feat = audio_feat.to(DEVICE)

    # -------------------------------
    # 3. Extract Text Features (robust)
    # -------------------------------
    text_feat = extract_text_embedding(video_path)

    if text_feat is None:
        print("ℹ️ No speech detected → using NULL text embedding")
        text_feat = torch.zeros(768)
        text_mask = 0
    else:
      text_mask = 1

    text_feat = text_feat.to(DEVICE)

    masks = torch.tensor([[text_mask, visual_mask,audio_mask]], device=DEVICE)

    # -------------------------------
    # 4. Model Prediction
    # -------------------------------
    with torch.no_grad():

        logits = model_em(
            audio_feat.unsqueeze(0),
            text_feat.unsqueeze(0),
            visual_feat.unsqueeze(0),
            masks
        )

        pred_class = torch.argmax(logits, dim=1).item()
        emotion = EMOTION_LABELS[pred_class]

    return  f"Predicted Emotion: **{emotion}**"

# ===============================
# ✅ Gradio UI
# ===============================

app = gr.Interface(
    fn=predict_emotion,
    inputs=gr.Video(label="Upload Video"),
    outputs=gr.Markdown(),
    title="🎭 Multimodal Emotion Detection",
    description="Upload a short video clip. The model will predict the emotion."
)

app.launch(share=True, debug=False)